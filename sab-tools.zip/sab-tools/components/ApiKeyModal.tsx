"use client";

import { useEffect, useState } from "react";
import { deleteDoc, doc, serverTimestamp, setDoc } from "firebase/firestore";
import { getDb } from "@/lib/firebase";
import type { Tool } from "@/lib/types";

type Props = {
  tool: Tool;
  uid: string;
  savedKey?: string;
  onClose: () => void;
};

export default function ApiKeyModal({ tool, uid, savedKey, onClose }: Props) {
  const [value, setValue] = useState(savedKey ?? "");
  const [reveal, setReveal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const ref = () => doc(getDb(), "users", uid, "apiKeys", tool.id);

  const save = async () => {
    const trimmed = value.trim();
    if (!trimmed) {
      setError("Enter your API key first.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await setDoc(ref(), { key: trimmed, toolName: tool.name, updatedAt: serverTimestamp() });
      onClose();
    } catch (e) {
      console.error(e);
      setError("Could not save the key. Check your connection and Firestore rules.");
      setBusy(false);
    }
  };

  const remove = async () => {
    setBusy(true);
    setError(null);
    try {
      await deleteDoc(ref());
      onClose();
    } catch (e) {
      console.error(e);
      setError("Could not remove the key.");
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label={`API key for ${tool.name}`}>
      <button aria-label="Close" onClick={onClose} className="absolute inset-0 animate-fadeIn bg-black/60" />
      <div className="relative w-full max-w-md animate-pop rounded-3xl border-2 border-black bg-white p-6 shadow-hard">
        <h3 className="font-display text-2xl uppercase">{tool.name}</h3>
        <p className="mt-1 text-sm text-black/60">
          Your key is stored privately in your account and is visible only to you.
        </p>

        <label className="mt-5 block text-xs font-bold uppercase tracking-wide" htmlFor="api-key">
          API key
        </label>
        <div className="relative mt-1">
          <input
            id="api-key"
            autoFocus
            type={reveal ? "text" : "password"}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void save()}
            placeholder="Paste your API key"
            autoComplete="off"
            spellCheck={false}
            className="w-full rounded-full border-2 border-black py-3 pl-5 pr-20 font-mono text-sm outline-none focus:ring-4 focus:ring-black/20"
          />
          <button
            type="button"
            onClick={() => setReveal((v) => !v)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold uppercase"
          >
            {reveal ? "Hide" : "Show"}
          </button>
        </div>

        {error && <p className="mt-3 text-sm font-semibold text-red-600">{error}</p>}

        <div className="mt-6 flex flex-wrap gap-3">
          <button
            onClick={() => void save()}
            disabled={busy}
            className="flex-1 rounded-full bg-black py-3 font-display uppercase text-white transition hover:shadow-pill disabled:opacity-50"
          >
            {busy ? "Saving..." : "Save key"}
          </button>
          {savedKey && (
            <button
              onClick={() => void remove()}
              disabled={busy}
              className="rounded-full border-2 border-black px-5 py-3 font-display uppercase transition hover:bg-black hover:text-white disabled:opacity-50"
            >
              Remove
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
