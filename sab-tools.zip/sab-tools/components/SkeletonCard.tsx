export default function SkeletonCard() {
  return (
    <div
      className="rounded-3xl border-2 border-black bg-white p-5 shadow-hard"
      aria-hidden="true"
    >
      <div className="flex items-start gap-4">
        <div className="shimmer h-16 w-16 shrink-0 animate-shimmer rounded-2xl" />
        <div className="flex-1 space-y-2 pt-1">
          <div className="shimmer h-4 w-2/3 animate-shimmer rounded-full" />
          <div className="shimmer h-3 w-1/3 animate-shimmer rounded-full" />
        </div>
      </div>
      <div className="mt-4 space-y-2">
        <div className="shimmer h-3 w-full animate-shimmer rounded-full" />
        <div className="shimmer h-3 w-5/6 animate-shimmer rounded-full" />
      </div>
      <div className="shimmer mt-5 h-11 w-full animate-shimmer rounded-full" />
    </div>
  );
}

export function SkeletonGrid({ count = 8 }: { count?: number }) {
  return (
    <div
      role="status"
      aria-label="Loading tools"
      className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
    >
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </div>
  );
}
