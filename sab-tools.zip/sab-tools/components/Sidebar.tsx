"use client";

import { CATEGORIES } from "@/lib/types";

type Props = {
  open: boolean;
  active: string;
  onSelect: (category: string) => void;
  onClose: () => void;
};

export default function Sidebar({ open, active, onSelect, onClose }: Props) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex">
      <aside
        className="relative z-50 flex h-full w-80 max-w-[85vw] animate-slideIn flex-col overflow-y-auto bg-white p-6 shadow-2xl"
        aria-label="Categories"
      >
        <div className="mb-8 text-center">
          <h2 className="font-display text-4xl leading-none">SAB TOOLS</h2>
          <p className="mt-1 text-xl font-bold">Options</p>
        </div>

        <nav className="flex flex-col gap-4">
          {CATEGORIES.map((cat) => {
            const isActive = active === cat;
            return (
              <button
                key={cat}
                onClick={() => {
                  onSelect(cat);
                  onClose();
                }}
                className="group flex items-center gap-4 text-left"
                aria-current={isActive ? "true" : undefined}
              >
                <span
                  className={`h-12 w-12 shrink-0 rounded-full border-4 border-black transition ${
                    isActive ? "bg-black" : "bg-white group-hover:bg-black"
                  }`}
                />
                <span
                  className={`flex-1 rounded-full px-6 py-3 text-center font-display text-lg uppercase tracking-wide transition ${
                    isActive
                      ? "bg-black text-white"
                      : "bg-black text-white opacity-90 group-hover:opacity-100 group-hover:shadow-pill"
                  }`}
                >
                  {cat === "All" ? "All Tools" : cat}
                </span>
              </button>
            );
          })}
        </nav>
      </aside>
      <button
        aria-label="Close menu"
        onClick={onClose}
        className="absolute inset-0 animate-fadeIn bg-black/50"
      />
    </div>
  );
}
