import type { Tool } from "@/lib/types";

type Props = {
  tool: Tool;
  hasKey: boolean;
  onUseKey: (tool: Tool) => void;
};

export default function ToolCard({ tool, hasKey, onUseKey }: Props) {
  return (
    <article className="flex flex-col rounded-3xl border-2 border-black bg-white p-5 shadow-hard transition hover:-translate-y-1">
      <div className="flex items-start gap-4">
        <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-black text-white">
          <span className="font-display text-xl">API</span>
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-lg font-extrabold leading-tight">{tool.name}</h3>
          <span className="mt-1 inline-block rounded-full border-2 border-black px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide">
            {tool.category}
          </span>
        </div>
      </div>

      <p className="mt-4 flex-1 text-sm leading-relaxed text-black/70">{tool.description}</p>

      <div className="mt-5 flex items-center gap-3">
        <button
          onClick={() => onUseKey(tool)}
          className="flex-1 rounded-full bg-black py-3 font-display text-sm uppercase tracking-wide text-white transition hover:shadow-pill"
        >
          {hasKey ? "Manage API key" : "Add API key"}
        </button>
        {tool.docsUrl && (
          <a
            href={tool.docsUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`${tool.name} documentation`}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-2 border-black transition hover:bg-black hover:text-white"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M7 17 17 7M8 7h9v9" />
            </svg>
          </a>
        )}
      </div>

      {hasKey && (
        <p className="mt-3 flex items-center gap-2 text-xs font-bold uppercase">
          <span className="h-2.5 w-2.5 rounded-full bg-black" /> Key saved
        </p>
      )}
    </article>
  );
}
