"use client";

import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";

type Props = {
  query: string;
  onQuery: (q: string) => void;
  onMenu: () => void;
};

export default function Header({ query, onQuery, onMenu }: Props) {
  const { user, signOut } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 border-b-2 border-black bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:gap-6 sm:px-6">
        <button
          onClick={onMenu}
          aria-label="Open menu"
          className="shrink-0 rounded-lg p-1 transition hover:bg-black/5"
        >
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2" />
            <line x1="8.5" y1="3" x2="8.5" y2="21" />
          </svg>
        </button>

        <h1 className="hidden font-display text-3xl leading-none sm:block">SAB TOOLS</h1>

        <div className="relative min-w-0 flex-1 sm:max-w-md">
          <input
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="Search tools..."
            aria-label="Search tools"
            className="w-full rounded-full bg-black py-3 pl-5 pr-12 text-sm text-white placeholder-white/60 shadow-pill outline-none focus:ring-4 focus:ring-black/20"
          />
          <svg className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-white" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="11" cy="11" r="7" />
            <line x1="20" y1="20" x2="16" y2="16" />
          </svg>
        </div>

        <div className="relative ml-auto shrink-0">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Account"
            className="flex h-11 w-11 items-center justify-center overflow-hidden rounded-full border-2 border-black bg-black"
          >
            {user?.photoURL ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={user.photoURL} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
            ) : (
              <svg width="26" height="26" viewBox="0 0 24 24" fill="white">
                <circle cx="12" cy="8" r="4.5" />
                <path d="M3.5 21c0-4.6 3.8-7.5 8.5-7.5s8.5 2.9 8.5 7.5z" />
              </svg>
            )}
          </button>

          {menuOpen && (
            <div className="absolute right-0 mt-2 w-60 animate-pop rounded-2xl border-2 border-black bg-white p-4 shadow-hard">
              <p className="truncate text-sm font-bold">{user?.displayName ?? "Signed in"}</p>
              <p className="truncate text-xs text-black/60">{user?.email}</p>
              <button
                onClick={() => {
                  setMenuOpen(false);
                  void signOut();
                }}
                className="mt-3 w-full rounded-full bg-black py-2 font-display text-sm uppercase text-white transition hover:shadow-pill"
              >
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
