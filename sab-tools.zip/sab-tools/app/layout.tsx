import type { Metadata, Viewport } from "next";
import { Inter, Rubik_Dirt } from "next/font/google";
import type { ReactNode } from "react";
import { AuthProvider } from "@/hooks/useAuth";
import "./globals.css";

const display = Rubik_Dirt({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-display",
});
const sans = Inter({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: "SAB Tools",
  description: "A catalogue of API tools. Save your keys and get building.",
};

export const viewport: Viewport = {
  themeColor: "#000000",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="min-h-screen bg-white font-sans text-black">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
