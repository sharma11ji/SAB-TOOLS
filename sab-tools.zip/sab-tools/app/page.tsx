"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { useAuth } from "@/hooks/useAuth";
import { getDb } from "@/lib/firebase";
import { seedSampleTools } from "@/lib/seed";
import type { Tool } from "@/lib/types";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import ToolCard from "@/components/ToolCard";
import ApiKeyModal from "@/components/ApiKeyModal";
import { SkeletonGrid } from "@/components/SkeletonCard";

export default function HomePage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [tools, setTools] = useState<Tool[] | null>(null);
  const [keys, setKeys] = useState<Record<string, string>>({});
  const [loadError, setLoadError] = useState<string | null>(null);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTool, setActiveTool] = useState<Tool | null>(null);
  const [seeding, setSeeding] = useState(false);

  const adminEmail = process.env.NEXT_PUBLIC_ADMIN_EMAIL;
  const isAdmin = !!adminEmail && user?.email === adminEmail;

  useEffect(() => {
    if (!authLoading && !user) router.replace("/login");
  }, [authLoading, user, router]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(getDb(), "tools"), orderBy("order", "asc"));
    return onSnapshot(
      q,
      (snap) => {
        setTools(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Tool, "id">) })));
        setLoadError(null);
      },
      (err) => {
        console.error(err);
        setLoadError("Could not load tools. Check your Firestore rules and config.");
        setTools([]);
      }
    );
  }, [user]);

  useEffect(() => {
    if (!user) return;
    return onSnapshot(
      collection(getDb(), "users", user.uid, "apiKeys"),
      (snap) => {
        const next: Record<string, string> = {};
        snap.forEach((d) => (next[d.id] = (d.data() as { key: string }).key));
        setKeys(next);
      },
      (err) => console.error(err)
    );
  }, [user]);

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return (tools ?? []).filter(
      (t) =>
        (category === "All" || t.category === category) &&
        (!s || t.name.toLowerCase().includes(s) || t.description.toLowerCase().includes(s))
    );
  }, [tools, category, search]);

  const handleSeed = async () => {
    setSeeding(true);
    try {
      await seedSampleTools();
    } catch (e) {
      console.error(e);
      setLoadError("Seeding failed. Make sure firestore.rules uses your admin email.");
    } finally {
      setSeeding(false);
    }
  };

  const showSkeleton = authLoading || !user || tools === null;

  return (
    <div className="min-h-screen">
      <Header query={search} onQuery={setSearch} onMenu={() => setSidebarOpen(true)} />
      <Sidebar
        open={sidebarOpen}
        active={category}
        onSelect={setCategory}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-4xl leading-none sm:text-5xl">
              {category === "All" ? "All Tools" : category}
            </h2>
            {!showSkeleton && (
              <p className="mt-2 text-sm font-semibold text-black/60">
                {filtered.length} {filtered.length === 1 ? "tool" : "tools"}
              </p>
            )}
          </div>
        </div>

        {loadError && (
          <p className="mb-6 rounded-2xl border-2 border-black bg-black p-4 text-sm font-semibold text-white">
            {loadError}
          </p>
        )}

        {showSkeleton ? (
          <SkeletonGrid />
        ) : filtered.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((tool) => (
              <ToolCard
                key={tool.id}
                tool={tool}
                hasKey={!!keys[tool.id]}
                onUseKey={setActiveTool}
              />
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border-2 border-dashed border-black p-10 text-center">
            <p className="font-display text-2xl">No tools found</p>
            <p className="mt-2 text-sm text-black/60">
              {tools && tools.length === 0
                ? "The catalogue is empty."
                : "Try a different search or category."}
            </p>
            {tools && tools.length === 0 && isAdmin && (
              <button
                onClick={() => void handleSeed()}
                disabled={seeding}
                className="mt-5 rounded-full bg-black px-6 py-3 font-display uppercase text-white transition hover:shadow-pill disabled:opacity-50"
              >
                {seeding ? "Seeding..." : "Seed sample tools"}
              </button>
            )}
          </div>
        )}
      </main>

      {activeTool && user && (
        <ApiKeyModal
          tool={activeTool}
          uid={user.uid}
          savedKey={keys[activeTool.id]}
          onClose={() => setActiveTool(null)}
        />
      )}
    </div>
  );
}
