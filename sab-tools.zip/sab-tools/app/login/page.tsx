"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";

export default function LoginPage() {
  const { user, loading, error, signInWithGoogle } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && user) router.replace("/");
  }, [loading, user, router]);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm animate-pop text-center">
        <h1 className="font-display text-6xl leading-none">SAB TOOLS</h1>

        <div className="mx-auto mt-10 flex h-40 w-40 items-center justify-center rounded-full bg-black">
          <svg width="96" height="96" viewBox="0 0 24 24" fill="white" aria-hidden="true">
            <circle cx="12" cy="8" r="4.5" />
            <path d="M3.5 21c0-4.6 3.8-7.5 8.5-7.5s8.5 2.9 8.5 7.5z" />
          </svg>
        </div>

        <button
          onClick={() => void signInWithGoogle()}
          disabled={loading}
          className="mt-10 flex w-full items-center justify-center gap-3 rounded-full bg-black px-6 py-4 font-display text-lg uppercase tracking-wide text-white shadow-pill transition hover:-translate-y-0.5 disabled:opacity-50"
        >
          <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
            <path fill="#fff" d="M21.6 12.2c0-.7-.1-1.4-.2-2H12v3.8h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3z" />
            <path fill="#fff" d="M12 22c2.7 0 4.9-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22z" />
            <path fill="#fff" d="M6.4 13.9a6 6 0 0 1 0-3.8V7.5H3.1a10 10 0 0 0 0 9z" />
            <path fill="#fff" d="M12 6c1.5 0 2.8.5 3.9 1.5l2.9-2.9A10 10 0 0 0 3.1 7.5l3.3 2.6C7.2 7.8 9.4 6 12 6z" />
          </svg>
          Sign in with Google
        </button>

        {error && <p className="mt-4 text-sm font-semibold text-red-600">{error}</p>}

        <p className="mt-6 text-xs text-black/50">
          Sign in to browse tools and save your API keys securely.
        </p>
      </div>
    </main>
  );
}
