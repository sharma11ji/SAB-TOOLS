export type Tool = {
  id: string;
  name: string;
  description: string;
  category: string;
  docsUrl?: string;
  order?: number;
};

export const CATEGORIES = [
  "All",
  "AI",
  "Payments",
  "Maps",
  "Data",
  "Messaging",
  "Dev",
] as const;
