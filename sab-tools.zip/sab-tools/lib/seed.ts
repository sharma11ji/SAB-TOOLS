import { doc, writeBatch } from "firebase/firestore";
import { getDb } from "./firebase";
import type { Tool } from "./types";

const SAMPLE: Omit<Tool, "id">[] = [
  { name: "OpenAI API", description: "Chat, image and embedding models for AI features.", category: "AI", docsUrl: "https://platform.openai.com/docs" },
  { name: "Gemini API", description: "Google's multimodal generative AI models.", category: "AI", docsUrl: "https://ai.google.dev" },
  { name: "Anthropic API", description: "Claude models for chat, analysis and agents.", category: "AI", docsUrl: "https://docs.claude.com" },
  { name: "Stripe API", description: "Accept cards and subscriptions worldwide.", category: "Payments", docsUrl: "https://stripe.com/docs/api" },
  { name: "Razorpay API", description: "UPI, cards and netbanking payments for India.", category: "Payments", docsUrl: "https://razorpay.com/docs/api" },
  { name: "Google Maps API", description: "Maps, geocoding and place search.", category: "Maps", docsUrl: "https://developers.google.com/maps" },
  { name: "Mapbox API", description: "Custom maps, directions and geocoding.", category: "Maps", docsUrl: "https://docs.mapbox.com" },
  { name: "OpenWeather API", description: "Current weather and forecasts by location.", category: "Data", docsUrl: "https://openweathermap.org/api" },
  { name: "NewsAPI", description: "Search headlines and articles from news sources.", category: "Data", docsUrl: "https://newsapi.org/docs" },
  { name: "Twilio API", description: "SMS, voice and WhatsApp messaging.", category: "Messaging", docsUrl: "https://www.twilio.com/docs" },
  { name: "SendGrid API", description: "Transactional and marketing email delivery.", category: "Messaging", docsUrl: "https://docs.sendgrid.com" },
  { name: "GitHub API", description: "Repositories, issues and pull requests.", category: "Dev", docsUrl: "https://docs.github.com/rest" },
];

export async function seedSampleTools(): Promise<void> {
  const db = getDb();
  const batch = writeBatch(db);
  SAMPLE.forEach((tool, index) => {
    const id = tool.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    batch.set(doc(db, "tools", id), { ...tool, order: index });
  });
  await batch.commit();
}
