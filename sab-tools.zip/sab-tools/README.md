# SAB Tools

Black-and-white sporty catalogue of API tools. Next.js 14 (App Router) + Tailwind + Firebase Auth (Google) + Firestore. Deploys to Vercel.

## 1. Run locally

```bash
npm install
cp .env.example .env.local   # then fill in the values (step 2)
npm run dev
```

## 2. Connect Firebase

1. Go to the [Firebase console](https://console.firebase.google.com) and create a project.
2. **Authentication → Sign-in method → Google → Enable.** Add your support email.
3. **Authentication → Settings → Authorized domains:** add `localhost` and your Vercel domain (e.g. `sab-tools.vercel.app`).
4. **Firestore Database → Create database** (production mode).
5. **Project settings → General → Your apps → Web app (`</>`)** → register, then copy the config values into `.env.local`:
   `NEXT_PUBLIC_FIREBASE_API_KEY`, `..._AUTH_DOMAIN`, `..._PROJECT_ID`, `..._STORAGE_BUCKET`, `..._MESSAGING_SENDER_ID`, `..._APP_ID`.
6. Set `NEXT_PUBLIC_ADMIN_EMAIL` to your Google account email.
7. Open `firestore.rules`, replace `REPLACE_WITH_YOUR_ADMIN_EMAIL@gmail.com` with the same email, and paste the file into **Firestore → Rules → Publish** (or run `firebase deploy --only firestore:rules`).

## 3. Add tools

Sign in with your admin account on an empty dashboard and click **Seed sample tools**, or add documents manually to the `tools` collection:

| field | type | example |
| --- | --- | --- |
| `name` | string | OpenAI API |
| `description` | string | Chat and image models |
| `category` | string | AI, Payments, Maps, Data, Messaging, Dev |
| `docsUrl` | string (optional) | https://platform.openai.com/docs |
| `order` | number | 0 |

Every document needs `order` (it is used for sorting).

User API keys are stored at `users/{uid}/apiKeys/{toolId}`; the rules make them readable only by their owner.

## 4. Deploy to Vercel via GitHub

```bash
git init && git add . && git commit -m "SAB Tools"
git branch -M main
git remote add origin https://github.com/<you>/sab-tools.git
git push -u origin main
```

1. On [vercel.com](https://vercel.com) click **Add New → Project** and import the repo (Next.js is auto-detected).
2. Under **Environment Variables** add all `NEXT_PUBLIC_*` values from `.env.local`.
3. Click **Deploy**. Every push to `main` now redeploys automatically.
4. Add the Vercel domain to Firebase **Authorized domains** (step 2.3), or Google sign-in will fail.

## Project structure

```
app/            layout, dashboard (page.tsx), login/
components/     Header, Sidebar, ToolCard, ApiKeyModal, SkeletonCard
hooks/          useAuth (Firebase Google auth context)
lib/            firebase.ts, types.ts, seed.ts
firestore.rules security rules
```

## Security note

API keys are stored in Firestore as plain text, protected by security rules. For production-grade secrecy, encrypt keys server-side (e.g. a Next.js route handler with Firebase Admin and a KMS) before storing.
